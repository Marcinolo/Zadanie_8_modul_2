from pymongo import MongoClient

# Połączenie z bazą danych
client = MongoClient("mongodb://localhost:27017/")  # Tutaj podaj adres i port Twojej bazy danych MongoDB
db = client["cluster0"]  # Tutaj podaj nazwę Twojej bazy danych MongoDB

def search_quotes(criteria):
    # Funkcja wyszukująca cytaty na podstawie kryteriów
    criteria = criteria.lower()

    # Wyszukiwanie cytatu po tagu
    if criteria.startswith('tag:'):
        tag = criteria[4:].strip()
        quotes = db.quotes.find({"tags": tag})
        return quotes

    # Wyszukiwanie cytatu po fullname autora
    elif criteria.startswith('fullname:'):
        fullname = criteria[9:].strip()
        author = db.authors.find_one({"fullname": {"$regex": fullname, "$options": "i"}})
        if author:
            quotes = db.quotes.find({"author": str(author["_id"])})
            return quotes

    # Wyszukiwanie cytatu po zestawie tagów
    elif criteria.startswith('tags:'):
        tags = criteria[5:].strip().split(',')
        quotes = db.quotes.find({"tags": {"$all": tags}})
        return quotes

    else:
        return None

def print_quotes(quotes):
    # Funkcja do wyświetlania cytatów
    if quotes.count() > 0:
        for quote in quotes:
            print(f"Author: {quote['author']}, Tags: {', '.join(quote['tags'])}, Quote: {quote['quote']}")
    else:
        print("Brak cytatu pasującego do podanych kryteriów.")

# Główna pętla programu
while True:
    command = input("Wpisz polecenie (np. 'tag: change' lub 'fullname: Albert Einstein'): ")
    command_parts = command.split(':')

    if len(command_parts) == 2:
        keyword, value = command_parts
        quotes = search_quotes(keyword.strip() + ': ' + value.strip())
        print_quotes(quotes)
    else:
        print("Nieprawidłowy format polecenia. Spróbuj ponownie.")