import json
from models import Author, Quote

# Wczytaj dane z pliku JSON
with open('authors.json', 'r') as file:
    authors_data = json.load(file)

# Iteruj przez każdego autora w danych
for author_data in authors_data:
    # Utwórz rekord autora w bazie danych
    author = Author(
        fullname=author_data['fullname'],
        born_date=author_data['born_date'],
        born_location=author_data['born_location'],
        description=author_data['description']
    )
    # Zapisz rekord autora w bazie danych
    author.save()

print("Dane z pliku authors.json zostały pomyślnie przesłane do bazy danych MongoDB.")

# Wczytaj dane z pliku JSON
with open('quotes.json', 'r') as file:
    quotes_data = json.load(file)

# Iteruj przez każdy cytat w danych
for quote_data in quotes_data:
    # Utwórz rekord cytatu w bazie danych
    quote = Quote(
        tags=quote_data['tags'],
        author=quote_data['author'],
        quote=quote_data['quote']
    )
    # Zapisz rekord cytatu w bazie danych
    quote.save()

print("Dane z pliku quotes.json zostały pomyślnie przesłane do bazy danych MongoDB.")