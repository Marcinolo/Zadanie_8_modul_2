from mongoengine import Document, StringField, ListField
import mongoengine

# Zdefiniuj domyślne połączenie do bazy danych MongoDB Atlas
mongoengine.connect(
    db='cluster0',
    host='0.0.0.0/0',
    username='marcinzolnowski',
    password='Qwerty777',
    authentication_source='admin'
)
class Author(Document):
    fullname = StringField(required=True)
    born_date = StringField()
    born_location = StringField()
    description = StringField()

class Quote(Document):
    tags = ListField(StringField())
    author = StringField(required=True)
    quote = StringField(required=True)